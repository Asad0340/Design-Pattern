/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package midterm;

/**
 *
 * @author Asad
 */

public class Main {
    public static void main(String[] args) {
        CricketMatch match = new CricketMatch("India vs Pakistan");
        User user1 = new User("User1");
        User user2 = new User("User2");

        match.registerObserver(user1);
        match.registerObserver(user2);

        MainScreen mainScreen = new MainScreen();
        mainScreen.clickOnMatch(match);
    }
}